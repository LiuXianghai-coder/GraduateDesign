create function update_user_share(s_id bigint) returns void
    language plpgsql
as
$$
DECLARE
    stars       INTEGER;
    num_comment INTEGER;
    collections INTEGER;
BEGIN
    SELECT count(*)
    INTO stars
    FROM user_share_star
    WHERE share_id = s_id
      AND star_flag = true;

    SELECT count(*)
    INTO num_comment
    FROM user_share_comment
    WHERE share_id = s_id;

    SELECT count(*) INTO collections
    FROM user_share_collections WHERE share_id = s_id
    AND collection_flag = true;

    UPDATE user_share SET star_num=stars, comment_num=num_comment, collections_num=collections WHERE share_id=s_id;
end;
$$;

alter function update_user_share(bigint) owner to postgres;


create function update_user_book_review(review_id bigint) returns void
    language plpgsql
as
$$
DECLARE

    stars       INTEGER;

    num_comment INTEGER;

BEGIN

    SELECT count(*)

    INTO stars

    FROM user_book_review_star

    WHERE book_review_id = review_id

      AND star_flag = true;



    SELECT count(*)

    INTO num_comment

    FROM user_book_review_comment

    WHERE book_review_id = review_id;



    UPDATE user_book_review SET star_num=stars, comment_num=num_comment WHERE book_review_id = review_id;

end;

$$;

alter function update_user_book_review(bigint) owner to postgres;

